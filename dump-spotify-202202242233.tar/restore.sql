--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.1
-- Dumped by pg_dump version 14.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE spotify;
--
-- Name: spotify; Type: DATABASE; Schema: -; Owner: -
--

CREATE DATABASE spotify WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'Vietnamese_Vietnam.1252';


\connect spotify

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: account; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.account (
    account_id integer NOT NULL,
    username character varying(60),
    current_password character varying(60),
    avatar character varying(60),
    user_role character varying(60),
    full_name character varying(60),
    birth_date date,
    email character varying(60),
    phone_number character varying(60),
    last_updated_stamp timestamp without time zone,
    created_stamp timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: account_account_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.account_account_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: account_account_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.account_account_id_seq OWNED BY public.account.account_id;


--
-- Name: album; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.album (
    album_id integer NOT NULL,
    artist_id integer NOT NULL,
    album_name character varying(60),
    album_image character varying(100),
    album_info character varying(1000),
    num_of_songs integer,
    total_duration real,
    last_updated_stamp timestamp without time zone,
    created_stamp timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: album_album_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.album_album_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: album_album_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.album_album_id_seq OWNED BY public.album.album_id;


--
-- Name: artist; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.artist (
    artist_id integer NOT NULL,
    artist_name character varying(60),
    artist_info character varying(1000),
    artist_image character varying(100),
    birth_date date,
    num_of_albums integer,
    num_of_songs integer,
    last_updated_stamp timestamp without time zone,
    created_stamp timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: artist_artist_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.artist_artist_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: artist_artist_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.artist_artist_id_seq OWNED BY public.artist.artist_id;


--
-- Name: artist_favorite; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.artist_favorite (
    client_id integer NOT NULL,
    artist_id integer NOT NULL,
    created_stamp timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: client; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client (
    client_id integer NOT NULL,
    account_id integer NOT NULL,
    num_artist_favorite integer,
    num_playlist integer
);


--
-- Name: client_client_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.client_client_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: client_client_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.client_client_id_seq OWNED BY public.client.client_id;


--
-- Name: comment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.comment (
    comment_id integer NOT NULL,
    client_id integer NOT NULL,
    song_id integer NOT NULL,
    comment_content character varying(1000),
    last_updated_stamp timestamp without time zone,
    created_stamp timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: comment_comment_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.comment_comment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: comment_comment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.comment_comment_id_seq OWNED BY public.comment.comment_id;


--
-- Name: playlist; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.playlist (
    playlist_id integer NOT NULL,
    client_id integer NOT NULL,
    playlist_name character varying(60),
    playlist_info character varying(1000),
    num_of_songs integer NOT NULL,
    total_duration real NOT NULL,
    last_updated_stamp timestamp without time zone,
    created_stamp timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: playlist_playlist_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.playlist_playlist_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: playlist_playlist_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.playlist_playlist_id_seq OWNED BY public.playlist.playlist_id;


--
-- Name: rating; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rating (
    rating_id integer NOT NULL,
    client_id integer NOT NULL,
    song_id integer NOT NULL,
    rating numeric,
    created_stamp timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: rating_rating_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.rating_rating_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: rating_rating_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.rating_rating_id_seq OWNED BY public.rating.rating_id;


--
-- Name: recently_listened; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recently_listened (
    song_id integer NOT NULL,
    client_id integer NOT NULL,
    created_stamp timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: song; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.song (
    song_id integer NOT NULL,
    artist_id integer NOT NULL,
    album_id integer,
    song_name character varying(60),
    song_info character varying(1000),
    song_link character varying(100),
    duration real,
    category character varying(60),
    sum_rate integer,
    num_of_ratings integer,
    num_of_comments integer,
    last_updated_stamp timestamp without time zone,
    created_stamp timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: song_added_to_playlist; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.song_added_to_playlist (
    song_id integer NOT NULL,
    playlist_id integer NOT NULL,
    created_stamp timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: song_song_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.song_song_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: song_song_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.song_song_id_seq OWNED BY public.song.song_id;


--
-- Name: account account_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account ALTER COLUMN account_id SET DEFAULT nextval('public.account_account_id_seq'::regclass);


--
-- Name: album album_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.album ALTER COLUMN album_id SET DEFAULT nextval('public.album_album_id_seq'::regclass);


--
-- Name: artist artist_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.artist ALTER COLUMN artist_id SET DEFAULT nextval('public.artist_artist_id_seq'::regclass);


--
-- Name: client client_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client ALTER COLUMN client_id SET DEFAULT nextval('public.client_client_id_seq'::regclass);


--
-- Name: comment comment_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment ALTER COLUMN comment_id SET DEFAULT nextval('public.comment_comment_id_seq'::regclass);


--
-- Name: playlist playlist_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.playlist ALTER COLUMN playlist_id SET DEFAULT nextval('public.playlist_playlist_id_seq'::regclass);


--
-- Name: rating rating_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rating ALTER COLUMN rating_id SET DEFAULT nextval('public.rating_rating_id_seq'::regclass);


--
-- Name: song song_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.song ALTER COLUMN song_id SET DEFAULT nextval('public.song_song_id_seq'::regclass);


--
-- Data for Name: account; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3406.dat

--
-- Data for Name: album; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3412.dat

--
-- Data for Name: artist; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3410.dat

--
-- Data for Name: artist_favorite; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3419.dat

--
-- Data for Name: client; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3408.dat

--
-- Data for Name: comment; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3418.dat

--
-- Data for Name: playlist; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3421.dat

--
-- Data for Name: rating; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3416.dat

--
-- Data for Name: recently_listened; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3423.dat

--
-- Data for Name: song; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3414.dat

--
-- Data for Name: song_added_to_playlist; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3422.dat

--
-- Name: account_account_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.account_account_id_seq', 4, true);


--
-- Name: album_album_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.album_album_id_seq', 2, true);


--
-- Name: artist_artist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.artist_artist_id_seq', 2, true);


--
-- Name: client_client_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.client_client_id_seq', 3, true);


--
-- Name: comment_comment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.comment_comment_id_seq', 4, true);


--
-- Name: playlist_playlist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.playlist_playlist_id_seq', 5, true);


--
-- Name: rating_rating_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.rating_rating_id_seq', 5, true);


--
-- Name: song_song_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.song_song_id_seq', 3, true);


--
-- Name: account pk_account; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account
    ADD CONSTRAINT pk_account PRIMARY KEY (account_id);


--
-- Name: album pk_album; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.album
    ADD CONSTRAINT pk_album PRIMARY KEY (album_id);


--
-- Name: artist pk_artist; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.artist
    ADD CONSTRAINT pk_artist PRIMARY KEY (artist_id);


--
-- Name: client pk_client; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT pk_client PRIMARY KEY (client_id);


--
-- Name: artist_favorite pk_client_artist; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.artist_favorite
    ADD CONSTRAINT pk_client_artist PRIMARY KEY (client_id, artist_id);


--
-- Name: comment pk_comment; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment
    ADD CONSTRAINT pk_comment PRIMARY KEY (comment_id);


--
-- Name: playlist pk_playlist; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.playlist
    ADD CONSTRAINT pk_playlist PRIMARY KEY (playlist_id);


--
-- Name: rating pk_rating; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rating
    ADD CONSTRAINT pk_rating PRIMARY KEY (rating_id);


--
-- Name: song pk_song; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.song
    ADD CONSTRAINT pk_song PRIMARY KEY (song_id);


--
-- Name: recently_listened pk_song_client; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recently_listened
    ADD CONSTRAINT pk_song_client PRIMARY KEY (song_id, client_id);


--
-- Name: song_added_to_playlist pk_song_playlist; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.song_added_to_playlist
    ADD CONSTRAINT pk_song_playlist PRIMARY KEY (song_id, playlist_id);


--
-- Name: song album_including; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.song
    ADD CONSTRAINT album_including FOREIGN KEY (album_id) REFERENCES public.album(album_id);


--
-- Name: album artist_composing; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.album
    ADD CONSTRAINT artist_composing FOREIGN KEY (artist_id) REFERENCES public.artist(artist_id);


--
-- Name: song artist_creating; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.song
    ADD CONSTRAINT artist_creating FOREIGN KEY (artist_id) REFERENCES public.artist(artist_id);


--
-- Name: artist_favorite artist_favored; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.artist_favorite
    ADD CONSTRAINT artist_favored FOREIGN KEY (artist_id) REFERENCES public.artist(artist_id);


--
-- Name: client client_account; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT client_account FOREIGN KEY (account_id) REFERENCES public.account(account_id);


--
-- Name: playlist client_created; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.playlist
    ADD CONSTRAINT client_created FOREIGN KEY (client_id) REFERENCES public.client(client_id);


--
-- Name: rating client_creating; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rating
    ADD CONSTRAINT client_creating FOREIGN KEY (client_id) REFERENCES public.client(client_id);


--
-- Name: comment client_creating; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment
    ADD CONSTRAINT client_creating FOREIGN KEY (client_id) REFERENCES public.client(client_id);


--
-- Name: artist_favorite client_favoring; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.artist_favorite
    ADD CONSTRAINT client_favoring FOREIGN KEY (client_id) REFERENCES public.client(client_id);


--
-- Name: recently_listened client_listened; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recently_listened
    ADD CONSTRAINT client_listened FOREIGN KEY (client_id) REFERENCES public.client(client_id);


--
-- Name: song_added_to_playlist playlist_included; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.song_added_to_playlist
    ADD CONSTRAINT playlist_included FOREIGN KEY (playlist_id) REFERENCES public.playlist(playlist_id);


--
-- Name: song_added_to_playlist song_added; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.song_added_to_playlist
    ADD CONSTRAINT song_added FOREIGN KEY (song_id) REFERENCES public.song(song_id);


--
-- Name: comment song_commented; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment
    ADD CONSTRAINT song_commented FOREIGN KEY (song_id) REFERENCES public.song(song_id);


--
-- Name: recently_listened song_listened; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recently_listened
    ADD CONSTRAINT song_listened FOREIGN KEY (song_id) REFERENCES public.song(song_id);


--
-- Name: rating song_rated; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rating
    ADD CONSTRAINT song_rated FOREIGN KEY (song_id) REFERENCES public.song(song_id);


--
-- PostgreSQL database dump complete
--

